import { Check, Copy } from "lucide-react";
import { useState } from "react";

export default function ResultBox({ label, language, text, accent = false }) {
  const [copied, setCopied] = useState(false);

  async function copyText() {
    if (!text) return;
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }

  return (
    <section className={`result-box ${accent ? "result-accent" : ""}`}>
      <div className="result-header">
        <div>
          <span>{label}</span>
          <strong>{language}</strong>
        </div>
        <button type="button" className="copy-button" onClick={copyText} disabled={!text}>
          {copied ? <Check size={16} /> : <Copy size={16} />} {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <p className={text ? "" : "placeholder-text"}>{text || "Your result will appear here."}</p>
    </section>
  );
}
