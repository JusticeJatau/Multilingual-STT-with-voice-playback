const languageNames = { ha: "Hausa", en: "English" };

function cleanJson(text) {
  return text.replace(/^```json\s*/i, "").replace(/\s*```$/i, "").trim();
}

export async function processAudioWithGemini(file, sourceLanguage, targetLanguage) {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    throw new Error("Gemini API key is not configured.");
  }

  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const prompt = `Listen carefully to this audio. The speaker is expected to use ${languageNames[sourceLanguage]}. Return only valid JSON with two string fields: transcript and translation. The transcript must preserve exactly what was spoken in ${languageNames[sourceLanguage]}, with normal punctuation. The translation must accurately express the same meaning in ${languageNames[targetLanguage]}. Do not explain your answer. If speech cannot be understood, use an empty string for both fields.`;

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [
              { text: prompt },
              {
                inlineData: {
                  mimeType: file.mimetype,
                  data: file.buffer.toString("base64")
                }
              }
            ]
          }
        ],
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "OBJECT",
            properties: {
              transcript: { type: "STRING" },
              translation: { type: "STRING" }
            },
            required: ["transcript", "translation"]
          }
        }
      })
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error?.message || "Gemini could not process the audio.");
  }

  const resultText = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!resultText) throw new Error("No speech result was returned.");

  return JSON.parse(cleanJson(resultText));
}

export function getDemoResult(sourceLanguage) {
  if (sourceLanguage === "ha") {
    return {
      transcript: "Ina son zuwa makaranta gobe da safe.",
      translation: "I want to go to school tomorrow morning."
    };
  }

  return {
    transcript: "Learning becomes easier when knowledge is shared.",
    translation: "Koyo yana zama mai sauƙi idan ana raba ilimi."
  };
}
